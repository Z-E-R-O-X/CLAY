<?php

const SERVERURL = "http://localhost/CLAY/";

const COMPANY = "CLAY";

const MONEDA = "$";

date_default_timezone_set("America/Bogota");