<?php

const SERVER = "localhost";
const DB = "";
const USER = "root";
const PASS = "";

const SGBD = "mysql:host=".SERVER.";dbname=".DB; 

const METHOD = "AES-256-CBC";
const SECRET_KEY = '$CLAY2f3a8b';
const SECRET_IV = '14032024';
