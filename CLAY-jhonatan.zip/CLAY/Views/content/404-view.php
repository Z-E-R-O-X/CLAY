<?php
echo "esta es la pagina de error";
?>