<?php
echo "esta es la pagina del home";
?>